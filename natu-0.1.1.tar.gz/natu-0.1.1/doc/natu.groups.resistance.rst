:orphan:

:mod:`natu.groups.resistance`
=============================

.. automodule:: natu.groups.resistance
   :members:
   :undoc-members:
   :show-inheritance: