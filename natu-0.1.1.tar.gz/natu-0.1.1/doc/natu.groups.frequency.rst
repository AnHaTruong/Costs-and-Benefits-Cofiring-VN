:orphan:

:mod:`natu.groups.frequency`
============================

.. automodule:: natu.groups.frequency
   :members:
   :undoc-members:
   :show-inheritance: