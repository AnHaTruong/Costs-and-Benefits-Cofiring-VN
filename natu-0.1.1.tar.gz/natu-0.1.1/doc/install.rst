:orphan:

Installation
============

The easiest way to install natu_ is to use pip_::

    > pip install natu

On Linux, it may be necessary to have root privileges::

    $ sudo pip install natu

Another way is to download and extract a copy of the package from the sidebar on
the left.  Run the following command from the base folder::

    > python setup.py install

Or, on Linux::

    $ sudo python setup.py install


.. _natu: index.html
.. _pip: https://pypi.python.org/pypi/pip
