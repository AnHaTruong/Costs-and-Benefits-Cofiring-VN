:orphan:

:mod:`natu.groups.potential`
============================

.. automodule:: natu.groups.potential
   :members:
   :undoc-members:
   :show-inheritance: