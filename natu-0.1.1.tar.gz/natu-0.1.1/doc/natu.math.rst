:mod:`natu.math`
================

.. automodule:: natu.math
   :members:
   :undoc-members:
   :show-inheritance:
